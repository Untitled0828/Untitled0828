const { Mod } = require("./src/script.js");
module.exports.mod = new Mod();