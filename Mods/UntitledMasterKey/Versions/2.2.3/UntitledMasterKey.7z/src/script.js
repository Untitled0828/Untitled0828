"use strict";
//const modPath = ModLoader.getModPath("UntitledMasterKey");

class MasterKeycard {
	constructor() {
		this.mod = "Untitled-MasterKey";
		Logger.info("Loading: " + this.mod);
		ModLoader.onLoad[this.mod] = this.load.bind(this);
	}

    load() {
        const cfg = require('../config.json').Config;

		const MasterKeycard_ID = "MasterKeycard";
        const MasterKey_ID = "MasterKey";
        const trader = "5c0647fdd443bc2504c2d371"; //Jaeger

		this.CreateNewItem("5efde6b4f5448336730dbd61", MasterKeycard_ID);
        this.CreateHandbookItem(MasterKeycard_ID, "5c164d2286f774194c5e69fa", cfg.KeycardPrice);
        this.CreateLocale(MasterKeycard_ID, "MasterKeycard", "MasterKeycard", "MasterKeycard");
        this.CreateTraderBarter(MasterKeycard_ID, cfg.KeycardPrice, 1, trader);


        this.CreateNewItem("5448ba0b4bdc2d02308b456c", MasterKey_ID);
        this.CreateHandbookItem(MasterKey_ID, "5c99f98d86f7745c314214b3", cfg.KeyPrice);
		this.CreateLocale(MasterKey_ID, "MasterKey", "MasterKey", "MasterKey");
        this.CreateTraderBarter(MasterKey_ID, cfg.KeyPrice, 1, trader);



        const MasterKeycard_Item = DatabaseServer.tables.templates.items[MasterKeycard_ID];
        MasterKeycard_Item._props.MaximumNumberOfUsage = 0;


		const MasterKey_Item = DatabaseServer.tables.templates.items[MasterKey_ID];
        MasterKey_Item._props.MaximumNumberOfUsage = 0;
    }


    CreateNewItem(idToClone, id)
    {
        const items = DatabaseServer.tables.templates.items;
        const clonedItem = JsonUtil.clone(items[idToClone]);
        items[id] = clonedItem;
        items[id]._id = id;
	}

    CreateHandbookItem(id, category, price)
    {
        const handbook = DatabaseServer.tables.templates.handbook;
        handbook.Items.push({
            "Id": id,
            "ParentId": category,
            "Price": price
        });
	}

	CreateLocale(id, itemName, itemShortName, itemDescription) {
        for (const locale in DatabaseServer.tables.locales.global) {
            DatabaseServer.tables.locales.global[locale].templates[id] =
            {
                "Name": itemName,
                "ShortName": itemShortName,
                "Description": itemDescription
            };
        }
	}

    CreateTraderBarter(id, itemTraderPrice, loyalty, traderID) {
        DatabaseServer.tables.traders[traderID].assort.items.push({ 
            "_id": id, 
            "_tpl": id, 
            "parentId": "hideout", 
            "slotId": "hideout", 
            "upd": { 
                "UnlimitedCount": true, 
                "StackObjectsCount": 999999 
            }
        })

        DatabaseServer.tables.traders[traderID].assort.barter_scheme[id] = [[{ "count": itemTraderPrice, "_tpl": "5449016a4bdc2d6f028b456f" }]];
        DatabaseServer.tables.traders[traderID].assort.loyal_level_items[id] = loyalty;
    }
}
module.exports.Mod = MasterKeycard;