"use strict";
const modPath = ModLoader.getModPath("UntitledAmmoCounter");

class AmmoCounter {
    constructor() {
        this.mod = "UntitledAmmoCounter";
        Logger.info("Loading: " + this.mod);
        ModLoader.onLoad[this.mod] = this.load.bind(this);
    }

    load() {
        // Items are added
        const item_path = "db/items/AmmoCounter.json";
        const item_object = JsonUtil.deserialize(VFS.readFile(`${modPath}/${item_path}`));
        DatabaseServer.tables.templates.items[item_object._id] = item_object;

        // Handbook entries are added
        const handbook_path = "db/templates/handbook/AmmoCounter.json";
        const handbook_item = JsonUtil.deserialize(VFS.readFile(`${modPath}/${handbook_path}`));
        DatabaseServer.tables.templates.handbook.Items.push(handbook_item)

        // Locale is fixed
        const locale_en_path = "db/locales/en/templates/AmmoCounter.json";
        const locale_kr_path = "db/locales/kr/templates/AmmoCounter.json";
        DatabaseServer.tables.locales.global.en.templates["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${locale_en_path}`));
        DatabaseServer.tables.locales.global.kr.templates["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${locale_kr_path}`));

        // Add item to ragfair
        const ragfair_path = "db/assort/ragfair/items/AmmoCounter.json";
        const ragfair_item = JsonUtil.deserialize(VFS.readFile(`${modPath}/${ragfair_path}`));
        DatabaseServer.tables.traders.ragfair.assort.items.push(ragfair_item);

        const loyal_path = "db/assort/ragfair/loyal_level_items/AmmoCounter.json";
        DatabaseServer.tables.traders.ragfair.assort.loyal_level_items["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${loyal_path}`));

        const barter_path = "db/assort/ragfair/barter_scheme/AmmoCounter.json";
        DatabaseServer.tables.traders.ragfair.assort.barter_scheme["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${barter_path}`));

        // Add item to mr. Jaeger
        const trader_path = "db/assort/5c0647fdd443bc2504c2d371/items/AmmoCounter.json";
        const trader_item = JsonUtil.deserialize(VFS.readFile(`${modPath}/${trader_path}`));
        DatabaseServer.tables.traders["5c0647fdd443bc2504c2d371"].assort.items.push(trader_item);

        const trader_loyal_path = "db/assort/5c0647fdd443bc2504c2d371/loyal_level_items/AmmoCounter.json";
        DatabaseServer.tables.traders["5c0647fdd443bc2504c2d371"].assort.loyal_level_items["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${trader_loyal_path}`));

        const trader_barter_path = "db/assort/5c0647fdd443bc2504c2d371/barter_scheme/AmmoCounter.json";
        DatabaseServer.tables.traders["5c0647fdd443bc2504c2d371"].assort.barter_scheme["AmmoCounter"] = JsonUtil.deserialize(VFS.readFile(`${modPath}/${trader_barter_path}`));


        for (var id in DatabaseServer.tables.templates.items) {
            var item = DatabaseServer.tables.templates.items[id];
            for (var i in item._props.Slots) {
                if (item._props.Slots[i]._name.includes("mod_tactical") != -1) {
                    for (var i2 in item._props.Slots[i]._props.filters[0].Filter) {
                        if (item._props.Slots[i]._props.filters[0].Filter[i2] == "61605d88ffa6e502ac5e7eeb") {
                            item._props.Slots[i]._props.filters[0].Filter.push("AmmoCounter");
                        }
                    }
                }
            }
        }
    }
}
module.exports.Mod = AmmoCounter;