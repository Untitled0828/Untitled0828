"use strict";
const mod = require("./package.json")
Logger.info(`Loading: ${mod.name} : ${mod.version}`);